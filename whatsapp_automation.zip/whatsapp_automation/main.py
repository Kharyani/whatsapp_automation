import pandas as pd
from sender import send_message
from scheduler import schedule_message
from templates import load_templates, apply_template
from logger import log_message
from utils import load_contacts


def format_phone(phone):
    """
    Format Pakistani phone numbers correctly
    """

    phone = str(phone).strip()

    # Convert 03xxxxxxxxx -> +923xxxxxxxxx
    if phone.startswith("03"):
        phone = "+92" + phone[1:]

    # Convert 92xxxxxxxxxx -> +92xxxxxxxxxx
    elif phone.startswith("92"):
        phone = "+" + phone

    # Validate
    elif not phone.startswith("+"):
        return None

    return phone


def menu():

    sent_numbers = set()

    while True:

        print("\n" + "=" * 45)
        print("   WHATSAPP AUTOMATION TOOL")
        print("=" * 45)

        print("1. Send Message")
        print("2. Bulk Messaging")
        print("3. Use Template")
        print("4. Schedule Message")
        print("5. View Logs")
        print("6. Exit")

        choice = input("Enter choice: ")

        # =========================================
        # 1. SEND SINGLE MESSAGE
        # =========================================
        if choice == "1":

            phone = input("Enter phone number: ")
            msg = input("Enter message: ")

            phone = format_phone(phone)

            if not phone:
                print("Invalid phone number format!")
                continue

            print("\n========== MESSAGE PREVIEW ==========")
            print(f"Number : {phone}")
            print(f"Message: {msg}")

            confirm = input("\nSend message? (y/n): ")

            if confirm.lower() != "y":
                print("Message cancelled.")
                continue

            status = send_message(phone, msg)

            log_message(phone, msg, status)

        # =========================================
        # 2. BULK MESSAGING
        # =========================================
        elif choice == "2":

            try:
                contacts = load_contacts()

                msg = input("Enter message: ")

                print("\n========== MESSAGE PREVIEW ==========")
                print(msg)

                confirm = input("\nSend to all contacts? (y/n): ")

                if confirm.lower() != "y":
                    print("Bulk messaging cancelled.")
                    continue

                for _, row in contacts.iterrows():

                    phone = format_phone(row["phone"])

                    if not phone:
                        print(f"Invalid number skipped: {row['phone']}")
                        continue

                    # Avoid duplicate messages
                    if phone in sent_numbers:
                        print(f"Duplicate skipped: {phone}")
                        continue

                    sent_numbers.add(phone)

                    print(f"\nSending to {row['name']} ({phone})")

                    status = send_message(phone, msg)

                    log_message(phone, msg, status)

            except Exception as e:
                print("Bulk messaging error:", e)

        # =========================================
        # 3. TEMPLATE MESSAGING
        # =========================================
        elif choice == "3":

            try:
                templates = load_templates()
                contacts = load_contacts()

                print("\nAvailable Templates:")
                for key in templates.keys():
                    print("-", key)

                t_name = input("\nChoose template: ")

                if t_name not in templates:
                    print("Template not found!")
                    continue

                for _, row in contacts.iterrows():

                    phone = format_phone(row["phone"])

                    if not phone:
                        print(f"Invalid number skipped: {row['phone']}")
                        continue

                    msg = apply_template(
                        templates[t_name],
                        row.to_dict()
                    )

                    print("\n========== MESSAGE PREVIEW ==========")
                    print(f"To      : {row['name']}")
                    print(f"Number  : {phone}")
                    print(f"Message : {msg}")

                    confirm = input("\nSend this message? (y/n): ")

                    if confirm.lower() != "y":
                        print("Skipped.")
                        continue

                    status = send_message(phone, msg)

                    log_message(phone, msg, status)

            except Exception as e:
                print("Template messaging error:", e)

        # =========================================
        # 4. SCHEDULE MESSAGE
        # =========================================
        elif choice == "4":

            try:
                phone = input("Enter phone number: ")
                msg = input("Enter message: ")
                send_time = input("Enter time (HH:MM): ")

                phone = format_phone(phone)

                if not phone:
                    print("Invalid phone number!")
                    continue

                print("\n========== SCHEDULE PREVIEW ==========")
                print(f"Number : {phone}")
                print(f"Message: {msg}")
                print(f"Time   : {send_time}")

                confirm = input("\nSchedule message? (y/n): ")

                if confirm.lower() != "y":
                    print("Scheduling cancelled.")
                    continue

                status = schedule_message(
                    send_message,
                    phone,
                    msg,
                    send_time
                )

                log_message(phone, msg, status)

            except Exception as e:
                print("Scheduling error:", e)

        # =========================================
        # 5. VIEW LOGS
        # =========================================
        elif choice == "5":

            try:
                print("\n========== MESSAGE LOGS ==========\n")

                with open("logs.txt", "r") as f:
                    logs = f.read()

                    if logs.strip() == "":
                        print("No logs found.")
                    else:
                        print(logs)

            except FileNotFoundError:
                print("Log file not found!")

        # =========================================
        # 6. EXIT
        # =========================================
        elif choice == "6":

            print("\nThank you for using the system!")
            break

        # =========================================
        # INVALID OPTION
        # =========================================
        else:
            print("Invalid choice! Please try again.")


if __name__ == "__main__":
    menu()