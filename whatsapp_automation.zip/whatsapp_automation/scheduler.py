import time
from datetime import datetime

def schedule_message(send_func, phone, message, send_time):
    while True:
        now = datetime.now().strftime("%H:%M")
        if now == send_time:
            status = send_func(phone, message)
            return status
        time.sleep(30)