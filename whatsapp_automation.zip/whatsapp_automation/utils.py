import pandas as pd

def load_contacts():
    df = pd.read_csv("contacts.csv", dtype=str)
    return df