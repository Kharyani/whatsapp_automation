from datetime import datetime

def log_message(phone, message, status):
    with open("logs.txt", "a") as f:
        f.write(f"{datetime.now()} | {phone} | {status} | {message}\n")