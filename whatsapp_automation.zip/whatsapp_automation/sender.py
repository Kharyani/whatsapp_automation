import pywhatkit as kit
from datetime import datetime
import time

def send_message(phone, message):
    try:
        now = datetime.now()

        hour = now.hour
        minute = now.minute + 2

        print(f"\nSending message to {phone}...")
        print("Please wait...")

        kit.sendwhatmsg(
            phone,
            message,
            hour,
            minute,
            wait_time=15,
            tab_close=True,
            close_time=3
        )

        time.sleep(5)

        print("Message sent successfully!")
        return "Sent"

    except Exception as e:
        print("Error:", e)
        return f"Failed: {str(e)}"