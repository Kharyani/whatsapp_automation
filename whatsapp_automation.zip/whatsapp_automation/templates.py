import json

def load_templates():
    with open("templates.json", "r") as f:
        return json.load(f)

def apply_template(template, data):

    for key, value in data.items():
        template = template.replace(
            f"{{{key}}}",
            str(value)
        )

    return template